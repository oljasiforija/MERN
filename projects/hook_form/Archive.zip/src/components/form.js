import React, { useState } from 'react';

const Form = (props) => {
    const[first_name, setFirstName] = useState("");
    const[last_name, setLastName] = useState("");
    const[email, setEmail] = useState("");
    const[password,setPassword] = useState("")
    const[confirm_password,setConfirmPassword] = useState("")



    const createUser = (e) => {
        e.preventDefault();
        const newUser = {first_name, last_name, email, password, confirm_password};
    }
    return (
        <div className="container">
            <form onSubmit={createUser}>
                <div className="label">
                    <label>First Name: </label>
                    <input type="text" onChange={(e) => setFirstName(e.target.value)}></input>
                </div>
                <div className="label">
                    <label>Last Name: </label>
                    <input type="text" onChange={(e) => setLastName(e.target.value)}></input>
                </div>
                <div className="label">
                    <label>Email: </label>
                    <input type="text" onChange={(e) => setEmail(e.target.value)}></input>
                </div>
                <div className="label">
                    <label>Password: </label>
                    <input type="password" onChange={(e) => setPassword(e.target.value)}></input>
                </div>
                <div className="label">
                    <label>Confirm Password: </label>
                    <input type="password" onChange={(e) => setConfirmPassword(e.target.value)}></input>
                </div>
                <input type="submit"></input>
            </form>
            <div>
                <p>First Name: {first_name}</p>
                <p>Last Name: {last_name}</p>
                <p> Email: {email}</p>
                <p>Password: {password}</p>
                <p>Confirm Password: {confirm_password}</p>
            </div>
        </div>
    )
}
export default Form