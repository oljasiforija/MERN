import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const SingleProduct = (props) => {
    const[singleProduct,setSingleProduct] = useState({});
    const{_id} = useParams();

    useEffect(()=> {
        axios.get("http://localhost:8000/api/products/" + _id)
        .then(res=>setSingleProduct(res.data.results))
        .catch(err => console.log(err))
    },[])
    return(
        <div>
            <h2>{singleProduct.title}</h2>
            <p>${singleProduct.price}</p>
            <p>{singleProduct.description}</p>
        </div>
    )
}

export default SingleProduct;