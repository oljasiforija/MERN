import React from 'react'
const Main = (props) => {
    return(
        <div>
            <h2>Here it is main one</h2>
        </div>
    )
}
export default Main;